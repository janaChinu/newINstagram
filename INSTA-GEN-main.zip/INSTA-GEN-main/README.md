# INSTA-GEN V2.0.1

_**Developed By : ZDAY-X**_




A TOOL TO **AUTOMATE CREATING INSTAGRAM ACCOUNTS**

____________________________________________________________________________

**DISCLAIMER: THIS TOOL IS BUILT PURELY FOR _EDUCATIONAL PURPOSES_ ONLY**

**I AM NOT RESPONSIBLE FOR YOUR ACTIONS**

TIP: Check out *GUI BRANCH* to see source code of the Gui Version of this software.
____________________________________________________________________________




![image](https://user-images.githubusercontent.com/83881453/149974578-89254d68-8992-4f7b-8d48-17782fe224b7.png)

#### _**CREATE UNLIMITED ACCOUNTS**_

![image](https://user-images.githubusercontent.com/83881453/149974059-fdaf20b3-7f3b-4baa-9176-d2efce3ef44c.png)


#### _AUTOMATE EMAIL VERIFICATION_

![image](https://user-images.githubusercontent.com/83881453/149974406-774faad5-cf73-4ca1-bf78-b89aaeb9a64c.png)


**NOTE: CREDENTIALS Of The Generated Accounts Will Be Stored In a File Called "cred.txt"**


____________________________________________________________________________
# INSTALLATION INSTRUCTIONS [DEBIAN LINUX]
____________________________________________________________________________

Clone the Repository
```bash
git clone https://github.com/Zday-X/INSTA-GEN.git
```
Change Directory
```bash
cd INSTA-GEN
```
Install The Dependencies
```bash
pip3 install -r requirements.txt
```
Make It Executable 
```bash
chmod +x inst-gen.py
```
Run The File
```bash
./inst-gen.py
```
____________________________________________________________________________
____________________________________________________________________________



## [![Repography logo](https://images.repography.com/logo.svg)](https://repography.com) / Recent activity [![Time period](https://images.repography.com/25069934/Zday-X/INSTA-GEN/recent-activity/218948358d811497243ff45ac44fba8d_badge.svg)](https://repography.com)
[![Timeline graph](https://images.repography.com/25069934/Zday-X/INSTA-GEN/recent-activity/218948358d811497243ff45ac44fba8d_timeline.svg)](https://github.com/Zday-X/INSTA-GEN/commits)
[![Issue status graph](https://images.repography.com/25069934/Zday-X/INSTA-GEN/recent-activity/218948358d811497243ff45ac44fba8d_issues.svg)](https://github.com/Zday-X/INSTA-GEN/issues)
[![Pull request status graph](https://images.repography.com/25069934/Zday-X/INSTA-GEN/recent-activity/218948358d811497243ff45ac44fba8d_prs.svg)](https://github.com/Zday-X/INSTA-GEN/pulls)
[![Trending topics](https://images.repography.com/25069934/Zday-X/INSTA-GEN/recent-activity/218948358d811497243ff45ac44fba8d_words.svg)](https://github.com/Zday-X/INSTA-GEN/commits)
[![Top contributors](https://images.repography.com/25069934/Zday-X/INSTA-GEN/recent-activity/218948358d811497243ff45ac44fba8d_users.svg)](https://github.com/Zday-X/INSTA-GEN/graphs/contributors)




_ENJOY ;)_
